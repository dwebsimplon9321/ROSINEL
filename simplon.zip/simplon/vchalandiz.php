<?php
    session_start();

    $_SESSION["communes"] = $_POST["inputCommune"];
if(isset($_SESSION["communes"])){
    header('Location: https://chalandiz.fr.gp/suivant.php');
    exit;
}